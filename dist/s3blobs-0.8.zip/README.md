Build the s3blobs Play Framework Module
---------------------------------------

    play deps --sync
    play build-module
